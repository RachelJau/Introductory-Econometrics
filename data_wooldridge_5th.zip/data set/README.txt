Microsoft Excel Data Sets
to accompany
Introductory Econometrics, 2e
by Wooldridge

Instructions:

PLEASE RESTART YOUR COMPUTER TO COMPLETE INSTALLATION

From the "Start" menu, select "Programs", then 
"Wooldridge2e", then "Excel" to access 
the data sets.

For technical support, please contact our 
technology support group. You can e-mail us at
support@kdc.com or call us at 800-423-0563.

